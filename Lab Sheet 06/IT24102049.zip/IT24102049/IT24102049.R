getwd()
setwd("C:/Users/it24102049/Desktop/IT24102049")
getwd()


# Exercise

# Question 1
# i)Distribution of X
# Binomial distribution with n=50 and p=0.85
p47 <- 1 - pbinom(46, 50, 0.85, lower.tail = TRUE) # P(X>=47)
#we use false if the value is greater

# Question 2
# i)Number of average calls receives per hour
# ii)Poisson distribution with lambda=12
p15 <- dpois(15, 12) # P(X=15)